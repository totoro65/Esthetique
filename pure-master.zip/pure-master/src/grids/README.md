Pure Grids
==========

Pure Grids ship with build-in 5ths- and 24ths-based units styles. The unit style
rules are generated via Pure's [`rework-pure-grids`][rework-pure-grids]
[Rework][] plugin.

The tooling used by Pure to generate its built-in Grids can also be used to
create custom Grids that use any nth-unit base.


[rework-pure-grids]: https://github.com/ericf/rework-pure-grids
[Rework]: https://github.com/visionmedia/rework
